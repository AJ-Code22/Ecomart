// InfiniteMenu removed: this file is now a simple null-export stub.

export default function InfiniteMenu() {
  return null;
}
