// InfiniteMenu removed; export a null default to avoid missing module errors.
const InfiniteMenu = () => null;
export default InfiniteMenu;
