export interface CartItem {
  id: string;
  title: string;
  price: number;
  currency: string;
  image: string;
  quantity: number;
}
