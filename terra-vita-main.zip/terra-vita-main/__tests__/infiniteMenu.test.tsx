// InfiniteMenu tests removed as the component was removed.
describe('InfiniteMenu placeholder', () => {
  it('placeholder does nothing', () => {
    expect(true).toBe(true);
  });
});
